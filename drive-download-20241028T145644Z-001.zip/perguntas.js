criaCartao(
    '1.quem sou eu?',
    '',
    'sou a ana carolina e gosto de animais'
)

criaCartao(
    '2.Minha familia é',
    '',
    'minha familia é unida, mas as vezes não'
)

criaCartao(
    '3.onde eu moro?',
    '',
    'Moro na rua rui barbosa, Bairro lindouro, -25.69222,-51.65689'
)

criaCartao(
    '4.Onde estudo?',
    '',
    'Colegio Estadual Mario Evaldo Morski. Ele foi criado em 1979 e é a melhor escola do nucleo de guarapuava '
)

criaCartao(
    '5.Como é minha turma? ',
    '',
    'Minha turma é boa em rendimento e é unida quando tem competições'
)

criaCartao(
    '6.Qual faculdade penso em fazer?',
    '',
    'Penso em fazer veterinária, por que amo animais'
)

criaCartao(
    '7.Como é minha cidade?',
    '',
    'Uma cidade meio movimentada com briga, festa, etc. Mas gosto de morar nela'
)

criaCartao(
    '8. Quai são os meus sonhos',
    '',
    'Construir uma familia, coneguir o trabalho dos sonhos, e dar bem na vida!'
)